# Motion prompts — два фильма по 10 секунд

Генерацию выполняете вы. Используйте один NOIR01_MASTER и утверждённые фотографии из серии. Если модель не выдаёт ровно 10 секунд, создайте отдельные короткие планы и соберите финальные 10 секунд в редакторе. Не ускоряйте движение до неестественного. Текстовые титры лучше добавить после генерации.

## 01 / Vertical — A moment, held.
**Назначение:** вертикальная product-реклама. **Формат:** 9:16, 1080×1920, 10 секунд, 24 или 25 fps. **Сайт:** `public/media/videos/vertical-ad.mp4`, постер `public/media/posters/vertical.webp`.

### Референсы
Приложите NOIR01_MASTER и фото studio-amber. Первый референс определяет геометрию, второй — свет и сцену. Финальный кадр подготовьте заранее: весь флакон в центральной безопасной области, место для титра сверху. Предмет стоит неподвижно во всех планах.

### Основной англоязычный промпт
> Create a 10-second vertical 9:16 cinematic fragrance advertisement for the fictional NOIR ESSENCE, using the attached NOIR01_MASTER as an immutable product identity reference and the attached amber studio photograph as the scene reference. One physical NOIR 01 bottle only: dense smoke-olive nearly black rectangular glass with softly rounded corners, weighted base, matte black rectangular cap, a thin antique-brass collar and one champagne paper label. Keep bottle proportions, label geometry and material identity constant in every frame. The bottle rests on a low warm resin pedestal in a dark cacao studio; the bottle does not rotate, float or move. Motion comes only from a very slow, stabilized camera push and a carefully controlled sweep of light. Frame a composition safe for vertical mobile display, with the cap and base kept away from extreme edges. Use realistic 85–100 mm product cinematography, shallow but sufficient depth of field, stable exposure, controlled warm highlights and deep detailed blacks. No generated overlay text. Preserve the attached final frame as the visual destination. Make the finished pacing calm and intentional rather than a fast montage. No morphing, label swimming, cap deformation, disappearing collar, liquid leaks, moving shadows that contradict the light, duplicate product, fake steam, dramatic explosions or neon effects.

### Раскадровка
| Время | Кадр и действие | Камера / свет / переход |
|---|---|---|
| 0,0–2,0 | Почти чёрный крупный план верхней грани. Появляется тонкий янтарный блик. | 100 мм macro; камера неподвижна, свет плавно открывается флагом; начало из чёрного за 0,3 с. |
| 2,0–4,5 | Средний крупный план фронта: стекло, кольцо, этикетка. | Склейка по одинаковому направлению блика; медленный push-in около 3% масштаба, фокус на этикетке, без focus hunting. |
| 4,5–7,0 | Полный флакон на подиуме, проявляется контур. | Мягкая склейка на утверждённый product shot; камера делает короткий боковой сдвиг не более 3 см, предмет неподвижен. |
| 7,0–10,0 | Финальный рекламный кадр: флакон целиком, свет стабилен. | Камера останавливается; последние 2 секунды полностью спокойны. В редакторе добавить NOIR ESSENCE / «Не просто аромат. Присутствие.»; без fade-out до 10,0. |

### Звук
Тихий низкий атмосферный тон с едва слышной воздушной текстурой. Один мягкий акцент при переходе к полному флакону на 4,5 с. Никаких резких ударов, навязчивой музыки и голосового обещания свойств. Используйте оригинальный или лицензированный звук. Ролик должен сохранять смысл без звука; сайт не включает звук автоматически.

### Safe area и экспорт
Титр не размещать в верхних 12% и нижних 18%; боковые поля минимум 8%. Проверяйте актуальный интерфейс платформы при публикации. Экспорт H.264, yuv420p, MP4, AAC при наличии аудио, faststart. Постер — финальный кадр без кнопки play. Не вшивайте контролы плеера в видео.

## 02 / Cinematic — Leave an impression.
**Назначение:** горизонтальный hero-film и презентация кампании. **Формат:** 16:9, 1920×1080, 10 секунд, 24 fps. **Сайт:** `public/media/videos/cinematic.mp4`, постер `public/media/posters/cinematic.webp`.

### Референсы
NOIR01_MASTER + hero photograph + studio-stone для материала подиума. Не смешивайте разные версии флакона. Последний кадр соответствует hero: флакон справа, слева свободное пространство.

### Основной англоязычный промпт
> Create a restrained 10-second horizontal 16:9 cinematic product film for the fictional NOIR ESSENCE fragrance campaign. Match the exact NOIR 01 bottle in NOIR01_MASTER in every shot: a weighted rectangular smoke-olive black glass body, subtly rounded corners, a matte black cap of fixed dimensions, a fine antique-brass collar and a single champagne paper label. Use the supplied hero photograph as the final composition reference. The scene is a minimal dark architectural studio with one charcoal stone plinth and a warm shaft of light. Keep the bottle physically stationary and grounded. Begin with an intimate material detail, reveal the relationship between glass and stone, and end with an elegant wide product tableau with negative space on the left. Simulate a full-frame cinema camera with 85 mm macro for the detail and 65–85 mm lens for the wide composition; no wide-angle distortion. Camera movement is a precise, slow dolly, not a handheld orbit. Dense shadows retain detail, highlights remain soft and warm, no clipped reflections. Palette limited to obsidian, dark chocolate, muted amber and champagne. Maintain identical geometry, label text, lighting direction and scale continuity across cuts. No morphing, bending bottle, floating cap, crawling label, impossible reflections, added objects, people, smoke clouds, particles, dramatic zooms, generated subtitles, random logos or watermark. Hold the final frame still for at least the last two seconds.

### Раскадровка
| Время | Содержание | Камера / свет / монтаж |
|---|---|---|
| 0,0–2,0 | Макро грани стекла и тонкого латунного кольца. Чёрный фон, тёплая линия. | 85–100 мм macro, плавный сдвиг вдоль грани на 2 см; фокус закреплён на одной плоскости. |
| 2,0–4,0 | Фронтальный средний план: этикетка и фактура бумажного волокна. | Прямая склейка по свету, 85 мм, медленный отъезд; не генерировать смену текста. |
| 4,0–7,0 | Открывается каменный подиум и тень; флакон в правой трети. | Смена на широкий план 65–85 мм; dolly-out примерно 5% масштаба, мягкий боковой свет и отрицательное заполнение. |
| 7,0–10,0 | Финальный кадр, совпадающий с hero-фото. | Отъезд затухает к 8,0 с. На 8,0–10,0 неподвижная композиция. Добавить слева NOIR ESSENCE / NOIR 01 · Eau de Parfum в редакторе. |

### Звук
Сдержанный протяжный тембр с очень мягкой низкой нотой, едва заметный звук движения воздуха между планами, спокойное затухание к 10 секунде. Голос не нужен. Не использовать узнаваемые мелодии или имитацию звука известного бренда.

### Финальный контроль
Покадрово проверьте 0, 2, 4, 7 и 10 секунды. Этикетка и крышка не должны «плыть». Нет лишних пальцев/предметов, внезапной смены стекла, мерцания экспозиции и неестественной траектории тени. Финальный кадр читается и как самостоятельный постер. Для сайта: H.264 MP4, faststart, 8–15 Мбит/с как отправная точка; размер оптимизировать после визуальной проверки. Сохраните монтажный мастер отдельно.
