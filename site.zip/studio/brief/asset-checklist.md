# Материалы кампании — 21 октября 2026

Все 6 изображений и 2 видео предоставлены пользователем и добавлены в проект. Оригиналы в Downloads не изменены.

| Файл в public/ | Размер / длительность | Статус |
|---|---|---|
| media/images/master-reference.jpg | 2400×1792 | Концепция / эталон |
| media/images/hero.jpg | 2752×1536 | Hero + галерея |
| media/images/studio-amber.jpg | 2400×1792 | Галерея |
| media/images/studio-stone.jpg | 2400×1792 | Галерея |
| media/images/studio-reflection.jpg | 2400×1792 | Галерея |
| media/images/lifestyle.jpg | 2400×1792 | Галерея |
| media/videos/vertical-ad.mp4 | 1080×1920, 8 с | A moment, held. |
| media/videos/cinematic.mp4 | 1920×1080, 10 с | Leave an impression. |
| media/posters/vertical.webp | 1080×1920 | Кадр видео на 1 с |
| media/posters/cinematic.webp | 1920×1080 | Кадр видео на 1 с |
| media/images/social-feed.webp | План: 1080×1350 | Создаёт пользователь |
| media/images/social-story.webp | План: 1080×1920 | Создаёт пользователь |
| media/images/social-banner.webp | План: 1920×1080 | Создаёт пользователь |

Исходные промпты описывают запланированные форматы. Реальные фотографии имеют пропорции, указанные выше; галерея показывает их без обрезки. Вертикальный фильм длится 8 секунд вместо запланированных 10.

После замены файлов выполните npm run build. Пути и пропорции определяются в lib/campaign.ts. Загрузка через интерфейс — временная примерка, исчезающая после обновления страницы.
